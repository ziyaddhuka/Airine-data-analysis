package xyz.supercoders.olddelayflights;

import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class OldFlightsDelayReducer extends Reducer<IntWritable, Text, IntWritable, Text> {

	public void reduce(IntWritable _key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
		// process values
		int arrdelay,depdelay,count=0,totaldelay=0;
		Float  avgtotaldelay;
		
		for (Text val : values) {

			String str=val.toString();
			String[] tokens =str.split(",");
			
			arrdelay=Integer.parseInt(tokens[0]);
			depdelay=Integer.parseInt(tokens[1]);
			totaldelay+=arrdelay+depdelay;
			count++;
		}
		
		avgtotaldelay=(float)(totaldelay/count);
		context.write(_key,new Text(count+" "+avgtotaldelay));
	}

}
