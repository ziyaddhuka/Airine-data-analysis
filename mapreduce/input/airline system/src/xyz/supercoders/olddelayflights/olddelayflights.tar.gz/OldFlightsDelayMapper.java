package xyz.supercoders.olddelayflights;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class OldFlightsDelayMapper extends Mapper<LongWritable, Text, IntWritable, Text> {

	public void map(LongWritable ikey, Text ivalue, Context context) throws IOException, InterruptedException {

		String line=ivalue.toString();
		String[] tokens =line.split(",");

		if(!(tokens[14].equals("NA") || tokens[15].equals("NA"))){
			
			int flightnum=Integer.parseInt(tokens[9]);
			String flightsdelay=(tokens[14]+","+tokens[15]);
			context.write(new IntWritable(flightnum), new Text(flightsdelay));
		}	
	}
}
